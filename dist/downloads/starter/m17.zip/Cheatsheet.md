# PyGame Cheat Sheet (Быстрая шпаргалка)

## 1) Инициализация и окно
```python
import pygame, sys
pygame.init()
W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Game')
clock = pygame.time.Clock()
is_running = True
while is_running:
    dt = clock.tick(60) / 1000.0  # FPS & delta-time
    for event in pygame.event.get():
        if event.type == pygame.QUIT: is_running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: is_running = False

    screen.fill((24,26,32))       # отрисовка
    pygame.display.flip()         # обновление кадра
pygame.quit(); sys.exit()
```

## 2) Цвета и координаты
- Цвет — кортеж `(R,G,B)` от 0 до 255.
- Ось X — вправо, ось Y — вниз. Левый верх экрана — `(0,0)`.

## 3) Время и FPS
```python
clock = pygame.time.Clock()
dt = clock.tick(60) / 1000.0   # секунды на кадр
```

## 4) Примитивы (pygame.draw)
```python
pygame.draw.line(screen, (200,200,220), (100,100), (300,120), 3)
pygame.draw.rect(screen, (90,150,240), (350,100,120,80), 0, border_radius=12)
pygame.draw.circle(screen, (255,190,60), (500,180), 30, 0)
```

## 5) Rect и атрибуты
```python
r = pygame.Rect(0,0,120,80)
r.center = (450,300)
r.move_ip(10,-5)            # inplace-сдвиг
r.inflate_ip(20,10)         # inplace-изменение размера
r.clamp_ip(screen.get_rect())
# якоря: r.topleft, r.midright, r.bottomleft ...
```

## 6) Движение
```python
keys = pygame.key.get_pressed()
v = pygame.Vector2((keys[pygame.K_RIGHT]-keys[pygame.K_LEFT]),
                   (keys[pygame.K_DOWN]-keys[pygame.K_UP]))
if v.length_squared() > 0: v = v.normalize()
r.move_ip(v.x * 260 * dt, v.y * 260 * dt)
```

## 7) Изображения (load/flip/rotate)
```python
img = pygame.image.load('assets/player.png').convert_alpha()
img2 = pygame.transform.flip(img, True, False)            # отражение по X
rot = pygame.transform.rotozoom(img, -angle_deg, 1.0)     # поворот по часовой
screen.blit(img, img.get_rect(center=(450,300)))
```

## 8) Градусы
- 0° — вправо; 90° — вниз (если используешь cos/sin).
- `rotate` — положительный угол против часовой; для «по часовой» используй отрицательный угол.

## 9) Звук (music + SFX)
```python
pygame.mixer.pre_init(44100, -16, 2, 512); pygame.init(); pygame.mixer.init()
pygame.mixer.music.load('assets/sounds/music.ogg')
pygame.mixer.music.play(-1); pygame.mixer.music.set_volume(0.6)
click = pygame.mixer.Sound('assets/sounds/click.wav'); click.set_volume(0.8)
pygame.mixer.find_channel(True).play(click)
```

## 10) События и таймеры
```python
USEREVENT_SPAWN = pygame.USEREVENT + 1
pygame.time.set_timer(USEREVENT_SPAWN, 1000)
for event in pygame.event.get():
    if event.type == USEREVENT_SPAWN: print('tick')
```

## 11) Ввод (мышь/текст)
```python
if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and rect.collidepoint(event.pos):
    dragging = True; offset = pygame.Vector2(event.pos) - rect.topleft
if event.type == pygame.MOUSEMOTION and dragging:
    rect.topleft = (event.pos[0]-offset.x, event.pos[1]-offset.y)

# Текст
if event.type == pygame.TEXTINPUT: name += event.text
if event.type == pygame.KEYDOWN and event.key == pygame.K_BACKSPACE: name = name[:-1]
```

## 12) Спрайты и группы
```python
class Ball(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface((20,20), pygame.SRCALPHA)
        pygame.draw.circle(self.image, (255,190,60), (10,10), 10)
        self.rect = self.image.get_rect(center=pos)
    def update(self, dt): pass

balls = pygame.sprite.Group(Ball((100,100)), Ball((200,200)))
balls.update(dt); balls.draw(screen)
```

## 13) Частые ошибки
- Не вызвано `pygame.init()`.
- Нет `pygame.display.flip()` или `Clock.tick()` — «зависшее» окно/100% CPU.
- Не нормализуешь диагональ — быстрее по диагонали.
- Пути к ассетам не существуют — оборачивай `load()` в `try/except`.
- Меняешь `image`, но не обновляешь `rect` — «скачки» позиции.

---

## Мини-шаблон проекта
```
project/
  main.py
  assets/
    player.png  bg.png
    sounds/ music.ogg click.wav
```
