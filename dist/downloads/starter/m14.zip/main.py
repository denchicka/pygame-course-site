# -*- coding: utf-8 -*-
import pygame, sys, os

# Модуль 14 — Персонаж (картинки): ходьба, разворот, прыжок, анимация (starter)
# Ожидаемая структура ассетов:
# assets/character/
#   idle_1.png idle_2.png
#   run_1.png  run_2.png  run_3.png  run_4.png
#   jump.png
# assets/bg.png  (необязательно)
#
# Если файлов нет — будут цветные заглушки.

pygame.init()
W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 14 — Персонаж (starter)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

GRAVITY = 1800.0
MOVE_SPEED = 320.0
JUMP_SPEED = 700.0
GROUND_Y = 520  # линия «земли»

def placeholder(size=(64,64), color=(120,170,250)):
    s = pygame.Surface(size, pygame.SRCALPHA)
    s.fill(color); pygame.draw.rect(s, (240,240,240), s.get_rect(), 2)
    return s

def load_image(path: str, fallback=(64,64)):
    try:
        return pygame.image.load(path).convert_alpha()
    except Exception:
        return placeholder(fallback)

def load_frames(folder: str, names: list[str], fallback=(64,64)):
    frames = []
    for name in names:
        frames.append(load_image(os.path.join(folder, name), fallback))
    return frames

# Загрузка фона
bg = load_image('assets/bg.png', (W, H))
bg = pygame.transform.scale(bg, (W, H))

# Кадры персонажа
idle_frames = load_frames('assets/character', ['idle_1.png', 'idle_2.png'])
run_frames  = load_frames('assets/character', ['run_1.png','run_2.png','run_3.png','run_4.png'])
jump_frame  = load_image('assets/character/jump.png')

# Состояние персонажа
pos = pygame.Vector2(W//2, GROUND_Y)
vel = pygame.Vector2(0, 0)
on_ground = True
facing = 1  # 1 вправо, -1 влево

anim_state = 'idle'  # 'idle' | 'run' | 'jump'
frame_index = 0
frame_time = 0.0
FRAME_IDLE = 0.5
FRAME_RUN  = 0.1

def get_current_frame():
    if anim_state == 'jump':
        return jump_frame
    elif anim_state == 'run':
        return run_frames[int(frame_index) % len(run_frames)]
    else:
        return idle_frames[int(frame_index) % len(idle_frames)]

running = True
while running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False

    # Ввод
    keys = pygame.key.get_pressed()
    move_dir = (1 if keys[pygame.K_d] or keys[pygame.K_RIGHT] else 0) - (1 if keys[pygame.K_a] or keys[pygame.K_LEFT] else 0)
    vel.x = move_dir * MOVE_SPEED
    if move_dir != 0:
        facing = 1 if move_dir > 0 else -1

    if (keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP]) and on_ground:
        vel.y = -JUMP_SPEED
        on_ground = False

    # Физика
    vel.y += GRAVITY * dt
    pos += vel * dt

    # Столкновение с «землёй»
    if pos.y > GROUND_Y:
        pos.y = GROUND_Y
        vel.y = 0
        on_ground = True

    # Анимация: выбор состояния
    if not on_ground:
        anim_state = 'jump'
    elif abs(vel.x) > 1:
        anim_state = 'run'
    else:
        anim_state = 'idle'

    # Счётчик кадров
    if anim_state == 'run':
        frame_time += dt
        if frame_time >= FRAME_RUN:
            frame_time -= FRAME_RUN
            frame_index = (frame_index + 1) % max(1, len(run_frames))
    elif anim_state == 'idle':
        frame_time += dt
        if frame_time >= FRAME_IDLE:
            frame_time -= FRAME_IDLE
            frame_index = (frame_index + 1) % max(1, len(idle_frames))
    else:
        frame_index = 0

    # Рендер
    screen.blit(bg, (0,0))
    # вычислим прямоугольник для центра
    frame = get_current_frame()
    if facing < 0:
        frame = pygame.transform.flip(frame, True, False)
    rect = frame.get_rect(midbottom=(int(pos.x), int(pos.y)))
    screen.blit(frame, rect)

    # UI
    tips = [
        'A/D или ←/→ — ходьба, SPACE/W/↑ — прыжок, ESC — выход',
        f'state={anim_state} facing={"right" if facing>0 else "left"} on_ground={on_ground} pos=({int(pos.x)},{int(pos.y)})'
    ]
    for i, t in enumerate(tips):
        screen.blit(font.render(t, True, (235,235,240)), (10, 10 + i*20))

    pygame.display.flip()

pygame.quit()
sys.exit()
