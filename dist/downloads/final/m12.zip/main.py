# -*- coding: utf-8 -*-
import pygame, sys

# Модуль 12 — Закрытие окна (final)

def main() -> None:
    pygame.init()
    W, H = 900, 600
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption('Модуль 12 — Закрытие окна (final)')
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 24)

    background_color = (26, 28, 34)
    is_running: bool = True
    show_confirm: bool = False

    def draw_ui() -> None:
        lines = [
            'ESC — выйти | Alt+F4 — системное закрытие (сгенерирует QUIT)',
            'Разница: break/return — выход из цикла/функции; pygame.quit() — выгрузка модулей; sys.exit() — завершение процесса.',
            'Опционально: диалог подтверждения (SPACE — да, N — нет)'
        ]
        for i, msg in enumerate(lines):
            screen.blit(font.render(msg, True, (235,235,240)), (12, 12 + i*22))

    # Можно заранее ограничить список событий (оптимизация)
    pygame.event.set_allowed([
        pygame.QUIT,
        pygame.KEYDOWN, pygame.KEYUP
    ])

    while is_running:
        dt = clock.tick(60) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Либо сразу:
                # is_running = False
                # Либо запрос подтверждения:
                show_confirm = True

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    show_confirm = True
                elif show_confirm and event.key == pygame.K_SPACE:
                    is_running = False
                elif show_confirm and event.key == pygame.K_n:
                    show_confirm = False

        screen.fill(background_color)
        draw_ui()

        if show_confirm:
            box = pygame.Rect(0, 0, 520, 160); box.center = (W//2, H//2)
            pygame.draw.rect(screen, (40, 46, 62), box, 0, border_radius=12)
            pygame.draw.rect(screen, (120, 160, 220), box, 2, border_radius=12)
            txt1 = font.render('Выйти из приложения?', True, (235,235,240))
            txt2 = font.render('SPACE — да, N — нет (ESC — снова спросить)', True, (200,210,220))
            screen.blit(txt1, (box.x + 24, box.y + 32))
            screen.blit(txt2, (box.x + 24, box.y + 78))

        pygame.display.flip()

    # Порядок корректного завершения:
    # 1) выйти из циклов и остановить свою логику
    # 2) pygame.quit() — выгрузить модули (звук, видео и пр.)
    # 3) sys.exit() — завершить интерпретатор (опционально в некоторых средах)
    pygame.quit()
    sys.exit()

if __name__ == '__main__':
    main()
