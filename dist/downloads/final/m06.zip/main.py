import pygame, sys
# Модуль 6 — Оси X/Y и система координат (final)

pygame.init()

screen_width, screen_height = 900, 600
screen_surface = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Модуль 6 — Оси X/Y (final)')
clock = pygame.time.Clock()

background_color = (24, 26, 32)
grid_color = (45, 50, 62)
axis_color = (120, 140, 200)
text_color = (230, 230, 235)
dot_color = (255, 200, 0)
rect_color = (80, 160, 240)

font_object = pygame.font.SysFont(None, 20)

dot_radius = 8
dot_x, dot_y = 450, 300

center_x = screen_width // 2
center_y = screen_height // 2

def draw_grid(surface: pygame.Surface, step: int = 50) -> None:
    w, h = surface.get_width(), surface.get_height()
    for x in range(0, w, step):
        pygame.draw.line(surface, grid_color, (x, 0), (x, h), 1)
    for y in range(0, h, step):
        pygame.draw.line(surface, grid_color, (0, y), (w, y), 1)

def draw_axes(surface: pygame.Surface, cx: int, cy: int) -> None:
    w, h = surface.get_width(), surface.get_height()
    pygame.draw.line(surface, axis_color, (cx, 0), (cx, h), 1)  # ось Y
    pygame.draw.line(surface, axis_color, (0, cy), (w, cy), 1)  # ось X
    pygame.draw.circle(surface, axis_color, (cx, cy), 3, 0)     # центр

def clamp(value: float, a: float, b: float) -> float:
    return max(a, min(b, value))

is_running = True
while is_running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_running = False

    mouse_x, mouse_y = pygame.mouse.get_pos()

    # Точка следует за мышью + зажим по краям
    dot_x = clamp(mouse_x, dot_radius, screen_width - dot_radius)
    dot_y = clamp(mouse_y, dot_radius, screen_height - dot_radius)

    screen_surface.fill(background_color)

    # Сетка и оси
    draw_grid(screen_surface, 50)
    draw_axes(screen_surface, center_x, center_y)

    # Прямоугольник 120x80 по центру (через get_rect(center=...))
    rect_surface = pygame.Surface((120, 80), pygame.SRCALPHA)
    pygame.draw.rect(rect_surface, rect_color, rect_surface.get_rect(), 2, border_radius=10)
    rect_pos = rect_surface.get_rect(center=(center_x, center_y))
    screen_surface.blit(rect_surface, rect_pos)

    # Подписи
    text1 = font_object.render(f"origin (0,0) — левый верх", True, text_color)
    text2 = font_object.render(f"center=({center_x},{center_y})", True, text_color)
    text3 = font_object.render(f"mouse=({mouse_x},{mouse_y})", True, text_color)
    screen_surface.blit(text1, (8, 8))
    screen_surface.blit(text2, (8, 28))
    screen_surface.blit(text3, (8, 48))

    # Точка-курсор
    pygame.draw.circle(screen_surface, dot_color, (int(dot_x), int(dot_y)), dot_radius, 0)

    pygame.display.flip()

pygame.quit()
sys.exit()
