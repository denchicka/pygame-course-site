# images.py — загрузка и поворот
import pygame
pygame.init(); screen = pygame.display.set_mode((600, 400))
img = pygame.Surface((100,60), pygame.SRCALPHA)
img.fill((120,170,250)); pygame.draw.rect(img, (240,240,240), img.get_rect(), 2)
for i in range(0,360,30):
    screen.fill((24,26,32))
    rot = pygame.transform.rotozoom(img, -i, 1.0)
    screen.blit(rot, rot.get_rect(center=(300,200)))
    pygame.display.flip(); pygame.time.wait(80)
