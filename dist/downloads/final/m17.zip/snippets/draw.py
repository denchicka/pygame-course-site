# draw.py — примитивы
import pygame
pygame.init(); screen = pygame.display.set_mode((600, 400))
screen.fill((24,26,32))
pygame.draw.rect(screen, (90,150,240), (50,50,120,80), 0, border_radius=12)
pygame.draw.line(screen, (200,200,220), (50,200), (250,220), 3)
pygame.draw.circle(screen, (255,190,60), (400,200), 40, 0)
pygame.display.flip(); pygame.time.wait(1500)
