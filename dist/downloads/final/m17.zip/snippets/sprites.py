# sprites.py — базовая группа
import pygame
class Dot(pygame.sprite.Sprite):
    def __init__(self, p):
        super().__init__()
        self.image = pygame.Surface((12,12), pygame.SRCALPHA)
        pygame.draw.circle(self.image, (255,190,60), (6,6), 6)
        self.rect = self.image.get_rect(center=p)
    def update(self, dt): pass

pygame.init(); screen = pygame.display.set_mode((400,200)); clock = pygame.time.Clock()
group = pygame.sprite.Group(Dot((60,100)), Dot((120,100)), Dot((180,100)))
run=True
while run:
    dt = clock.tick(60)/1000.0
    for e in pygame.event.get():
        if e.type == pygame.QUIT: run=False
    screen.fill((24,26,32)); group.update(dt); group.draw(screen); pygame.display.flip()
pygame.quit()
