# events.py — пользовательский таймер
import pygame
pygame.init(); screen = pygame.display.set_mode((400,200)); clock = pygame.time.Clock()
TICK = pygame.USEREVENT + 1; pygame.time.set_timer(TICK, 500)
running = True; n = 0
while running:
    dt = clock.tick(60)
    for e in pygame.event.get():
        if e.type == pygame.QUIT: running = False
        if e.type == TICK: n += 1
    screen.fill((24,26,32))
    pygame.display.set_caption(f'Ticks: {n}')
    pygame.display.flip()
pygame.quit()
