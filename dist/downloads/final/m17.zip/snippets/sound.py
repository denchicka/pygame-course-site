# sound.py — музыка + эффект (требуются файлы в assets/sounds/)
import pygame, os
pygame.mixer.pre_init(44100, -16, 2, 512); pygame.init(); pygame.mixer.init()
music = os.path.join('assets','sounds','music.ogg')
click = os.path.join('assets','sounds','click.wav')
try:
    pygame.mixer.music.load(music); pygame.mixer.music.play(-1)
    snd = pygame.mixer.Sound(click); pygame.mixer.find_channel(True).play(snd)
    pygame.time.wait(1200)
finally:
    pygame.mixer.music.stop(); pygame.quit()
