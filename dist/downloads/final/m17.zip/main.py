# -*- coding: utf-8 -*-
import pygame, sys

# Мини-шаблон проекта (готов к копированию)
def main() -> None:
    pygame.init()
    W, H = 900, 600
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption('Template')
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 20)

    is_running = True
    while is_running:
        dt = clock.tick(60) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT: is_running = False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: is_running = False

        screen.fill((24,26,32))
        screen.blit(font.render('Hello, PyGame!', True, (235,235,240)), (20,20))
        pygame.display.flip()

    pygame.quit(); sys.exit()

if __name__ == '__main__':
    main()
