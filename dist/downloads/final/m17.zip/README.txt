Module 17 — PyGame Cheat Sheet

Содержимое:
- Cheatsheet.md — краткая шпаргалка по ключевым API и шаблонам.
- main.py — минимальный шаблон проекта.
- snippets/ — короткие примеры: draw.py, images.py, sound.py, events.py, sprites.py.

Запуск:
python main.py
