# -*- coding: utf-8 -*-
import pygame, sys, os

# Модуль 14 — Персонаж (картинки): ходьба, разворот, прыжок, анимация, платформа (final)

pygame.init()
W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 14 — Персонаж (final)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

GRAVITY = 1900.0
MOVE_SPEED = 340.0
JUMP_SPEED = 760.0
GROUND_Y = 520

def placeholder(size=(64,64), color=(120,170,250)):
    s = pygame.Surface(size, pygame.SRCALPHA)
    s.fill(color); pygame.draw.rect(s, (240,240,240), s.get_rect(), 2)
    return s

def load_image(path: str, fallback=(64,64)):
    try:
        return pygame.image.load(path).convert_alpha()
    except Exception:
        return placeholder(fallback)

def load_frames(folder: str, names: list[str], fallback=(64,64)):
    return [load_image(os.path.join(folder, n), fallback) for n in names]

# Фон
bg = load_image('assets/bg.png', (W, H))
bg = pygame.transform.scale(bg, (W, H))

# Кадры
idle_frames = load_frames('assets/character', ['idle_1.png','idle_2.png'])
run_frames  = load_frames('assets/character', ['run_1.png','run_2.png','run_3.png','run_4.png'])
jump_frame  = load_image('assets/character/jump.png')

# Платформы (Rect)
platforms = [
    pygame.Rect(100, 460, 200, 20),
    pygame.Rect(420, 400, 160, 20),
    pygame.Rect(640, 500, 180, 20),
]

class Character:
    def __init__(self):
        self.pos = pygame.Vector2(W//2, GROUND_Y)
        self.vel = pygame.Vector2(0, 0)
        self.on_ground = True
        self.facing = 1
        self.state = 'idle'
        self.frame_index = 0
        self.frame_time = 0.0
        self.FR_IDLE = 0.5
        self.FR_RUN  = 0.085

    def current_surface(self) -> pygame.Surface:
        if self.state == 'jump':
            return jump_frame
        elif self.state == 'run':
            return run_frames[int(self.frame_index) % max(1, len(run_frames))]
        else:
            return idle_frames[int(self.frame_index) % max(1, len(idle_frames))]

    def update(self, dt: float, keys) -> None:
        # ввод
        dirx = (1 if (keys[pygame.K_d] or keys[pygame.K_RIGHT]) else 0) - (1 if (keys[pygame.K_a] or keys[pygame.K_LEFT]) else 0)
        self.vel.x = dirx * MOVE_SPEED
        if dirx != 0: self.facing = 1 if dirx > 0 else -1

        if (keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP]) and self.on_ground:
            self.vel.y = -JUMP_SPEED
            self.on_ground = False

        # гравитация
        self.vel.y += GRAVITY * dt

        # движение по X и коллизии по X
        self.pos.x += self.vel.x * dt
        # прямоугольник персонажа для коллизий — берём из текущего кадра
        rect = self.get_rect()
        rect.centerx = int(self.pos.x)
        for p in platforms:
            if rect.colliderect(p):
                if self.vel.x > 0:
                    rect.right = p.left
                elif self.vel.x < 0:
                    rect.left  = p.right
                self.pos.x = rect.centerx

        # движение по Y и коллизии по Y
        self.pos.y += self.vel.y * dt
        rect.centery = int(self.pos.y)
        self.on_ground = False
        # земля как платформа
        ground_rect = pygame.Rect(0, GROUND_Y, W, H - GROUND_Y)
        for p in platforms + [ground_rect]:
            if rect.colliderect(p):
                if self.vel.y > 0:   # падение
                    rect.bottom = p.top
                    self.pos.y = rect.centery
                    self.vel.y = 0
                    self.on_ground = True
                elif self.vel.y < 0: # удар головой
                    rect.top = p.bottom
                    self.pos.y = rect.centery
                    self.vel.y = 0

        # состояние анимации
        if not self.on_ground:
            self.state = 'jump'
            self.frame_index = 0
        elif abs(self.vel.x) > 1:
            self.state = 'run'
            self.frame_time += dt
            if self.frame_time >= self.FR_RUN:
                self.frame_time -= self.FR_RUN
                self.frame_index = (self.frame_index + 1) % max(1, len(run_frames))
        else:
            self.state = 'idle'
            self.frame_time += dt
            if self.frame_time >= self.FR_IDLE:
                self.frame_time -= self.FR_IDLE
                self.frame_index = (self.frame_index + 1) % max(1, len(idle_frames))

        # зажим по экрану по X
        self.pos.x = max(24, min(W - 24, self.pos.x))

    def get_rect(self) -> pygame.Rect:
        surf = self.current_surface()
        rect = surf.get_rect()
        rect.midbottom = (int(self.pos.x), int(self.pos.y))
        return rect

    def draw(self, surface: pygame.Surface) -> None:
        surf = self.current_surface()
        if self.facing < 0: surf = pygame.transform.flip(surf, True, False)
        rect = surf.get_rect(midbottom=(int(self.pos.x), int(self.pos.y)))
        surface.blit(surf, rect)

hero = Character()

running = True
while running:
    dt = clock.tick(60) / 1000.0
    for event in pygame.event.get():
        if event.type == pygame.QUIT: running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: running = False

    keys = pygame.key.get_pressed()
    hero.update(dt, keys)

    # Рендер
    screen.blit(bg, (0,0))
    # платформы
    for p in platforms:
        pygame.draw.rect(screen, (70, 90, 120), p, 0, border_radius=6)
        pygame.draw.rect(screen, (160, 190, 230), p, 2, border_radius=6)

    # земля
    pygame.draw.rect(screen, (60, 120, 80), (0, GROUND_Y, W, H-GROUND_Y))

    hero.draw(screen)

    info = [
        'A/D или ←/→ — ходьба | SPACE/W/↑ — прыжок | ESC — выход',
        f'state={hero.state} on_ground={hero.on_ground} pos=({int(hero.pos.x)},{int(hero.pos.y)})'
    ]
    for i, t in enumerate(info):
        screen.blit(font.render(t, True, (235,235,240)), (10, 10 + i*20))

    pygame.display.flip()

pygame.quit()
sys.exit()
