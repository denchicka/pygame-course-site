import pygame, sys
# Модуль 6 — Оси X/Y и система координат (starter)
# ЗАДАЧИ (ищи TODO ниже):
# 1) Нарисуй оси X/Y через центр экрана (тонкие линии).
# 2) Сделай сетку с шагом 50 пикселей.
# 3) Выводи координаты мыши в левом верхнем углу (pygame.font).
# 4) Построй прямоугольник 120x80 по центру экрана через get_rect(center=(...)).
# 5) Нарисуй круг, который следует за мышью; ограничь его внутри экрана (clamp).

pygame.init()

screen_width, screen_height = 900, 600
screen_surface = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Модуль 6 — Оси X/Y (starter)')
clock = pygame.time.Clock()

background_color = (24, 26, 32)
grid_color = (45, 50, 62)
axis_color = (120, 140, 200)
text_color = (230, 230, 235)
dot_color = (255, 200, 0)

# Шрифт для текста координат
font_object = pygame.font.SysFont(None, 20)

# Параметры движущейся точки
dot_radius = 8
dot_x, dot_y = 450, 300  # старт

# Центр экрана
center_x = screen_width // 2
center_y = screen_height // 2

is_running = True
while is_running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_running = False

    # === ЛОГИКА ===
    mouse_x, mouse_y = pygame.mouse.get_pos()
    # TODO-5: точка следует за мышью и зажимается в пределах экрана
    dot_x, dot_y = mouse_x, mouse_y
    dot_x = max(dot_radius, min(screen_width - dot_radius, dot_x))
    dot_y = max(dot_radius, min(screen_height - dot_radius, dot_y))

    # === ОТРИСОВКА ===
    screen_surface.fill(background_color)

    # TODO-2: сетка 50px
    step = 50
    for x in range(0, screen_width, step):
        pygame.draw.line(screen_surface, grid_color, (x, 0), (x, screen_height), 1)
    for y in range(0, screen_height, step):
        pygame.draw.line(screen_surface, grid_color, (0, y), (screen_width, y), 1)

    # TODO-1: оси X/Y через центр
    pygame.draw.line(screen_surface, axis_color, (center_x, 0), (center_x, screen_height), 1)
    pygame.draw.line(screen_surface, axis_color, (0, center_y), (screen_width, center_y), 1)

    # TODO-4: прямоугольник по центру
    rect = pygame.Rect(0, 0, 120, 80)
    rect.center = (center_x, center_y)
    pygame.draw.rect(screen_surface, (80, 160, 240), rect, 2)

    # Точка-курсор
    pygame.draw.circle(screen_surface, dot_color, (int(dot_x), int(dot_y)), dot_radius, 0)

    # TODO-3: текст координат мыши
    text_surface = font_object.render(f"mouse: ({mouse_x}, {mouse_y})", True, text_color)
    screen_surface.blit(text_surface, (8, 8))

    pygame.display.flip()

pygame.quit()
sys.exit()
