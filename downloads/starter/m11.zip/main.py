# -*- coding: utf-8 -*-
import pygame, sys, os

# Модуль 11 — Звук (starter)
# Ожидаемая структура ассетов:
# assets/sounds/
#   music.ogg
#   click.wav
#   jump.wav
#   explosion.wav
#
# ЗАДАЧИ (TODO):
# 1) Инициализировать микшер: pygame.mixer.pre_init(44100, -16, 2, 512); pygame.mixer.init()
# 2) Загрузить и включить фоновую музыку: mixer.music.load('assets/sounds/music.ogg'); mixer.music.play(-1)
# 3) Регулировать громкость музыки клавишами [+] и [-] (0.0..1.0)
# 4) Загружать SFX (Sound) и проигрывать по 1/2/3; регулировать их громкость клавишами [ ] (левая/правая скобка)
# 5) Пауза/продолжение/стоп музыки: P — pause/unpause, S — stop, F — fadeout(1000)
# 6) Назначить отдельные каналы для SFX (set_num_channels, find_channel)
# 7) Вывести на экран текущие уровни громкости и статус музыки

# Инициализация
pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()

W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 11 — Звук (starter)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 22)

# === МИКШЕР И ЗАГРУЗКА ===
try:
    pygame.mixer.init()
except Exception as e:
    print('Ошибка mixer.init():', e)

MUSIC_PATH = 'assets/sounds/music.ogg'
SFX_PATHS = {
    '1': 'assets/sounds/click.wav',
    '2': 'assets/sounds/jump.wav',
    '3': 'assets/sounds/explosion.wav',
}

music_volume = 0.6
sfx_volume = 0.8

# Музыка
try:
    pygame.mixer.music.load(MUSIC_PATH)
    pygame.mixer.music.set_volume(music_volume)
    # pygame.mixer.music.play(-1)  # TODO-2 включить по циклу
except Exception as e:
    print('Музыка не загружена:', e)

# SFX
sfx = {}
for key, path in SFX_PATHS.items():
    try:
        sound = pygame.mixer.Sound(path)
        sound.set_volume(sfx_volume)
        sfx[key] = sound
    except Exception as e:
        print(f'SFX {path} не загружен:', e)

pygame.mixer.set_num_channels(16)

def vol_clamp(x: float) -> float:
    return max(0.0, min(1.0, x))

running = True
while running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_m:
                # старт/стоп музыки (пример простого тумблера)
                if pygame.mixer.music.get_busy():
                    pygame.mixer.music.stop()
                else:
                    pygame.mixer.music.play(-1)

            if event.key == pygame.K_p:
                # пауза/продолжить
                pygame.mixer.music.pause() if pygame.mixer.music.get_busy() else pygame.mixer.music.unpause()
            if event.key == pygame.K_s:
                pygame.mixer.music.stop()
            if event.key == pygame.K_f:
                pygame.mixer.music.fadeout(1000)

            # громкость музыки
            if event.key in (pygame.K_EQUALS, pygame.K_PLUS):   # [+]
                music_volume = vol_clamp(music_volume + 0.05)
                pygame.mixer.music.set_volume(music_volume)
            if event.key == pygame.K_MINUS:                      # [-]
                music_volume = vol_clamp(music_volume - 0.05)
                pygame.mixer.music.set_volume(music_volume)

            # громкость SFX
            if event.key == pygame.K_LEFTBRACKET:                # [
                sfx_volume = vol_clamp(sfx_volume - 0.05)
                for snd in sfx.values(): snd.set_volume(sfx_volume)
            if event.key == pygame.K_RIGHTBRACKET:               # ]
                sfx_volume = vol_clamp(sfx_volume + 0.05)
                for snd in sfx.values(): snd.set_volume(sfx_volume)

            # проигрывание SFX
            if event.unicode in ('1','2','3') and event.unicode in sfx:
                ch = pygame.mixer.find_channel(True)  # выделить свободный канал
                if ch: ch.play(sfx[event.unicode])

    screen.fill((26, 28, 34))
    y = 12
    def line(msg):
        nonlocal y
        screen.blit(font.render(msg, True, (235,235,240)), (12, y))
        y += 22

    line('M — старт/стоп музыки | P — пауза, S — стоп, F — затухание')
    line('[ / ] — громкость SFX | +/- — громкость музыки')
    line('1/2/3 — эффекты (click/jump/explosion)')
    line(f'music volume: {music_volume:.2f} | sfx volume: {sfx_volume:.2f} | music busy: {pygame.mixer.music.get_busy()}')

    pygame.display.flip()

pygame.quit()
sys.exit()
