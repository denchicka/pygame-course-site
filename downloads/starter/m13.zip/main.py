# -*- coding: utf-8 -*-
import pygame, sys, random

# Модуль 13 — Система событий (starter)
# Цели:
# - Понять очередь событий pygame: QUIT, KEYDOWN/UP, MOUSEBUTTON*, MOUSEMOTION, MOUSEWHEEL, USEREVENT.
# - Узнать, чем отличаются события клавиатуры от опроса состояний (key.get_pressed()).
# - Реализовать перетаскивание прямоугольника мышью.
# - Настроить таймер‑события через pygame.time.set_timer.
# - Отправлять свои события через pygame.event.post.
#
# Управление:
#  • ESC — выход
#  • ЛКМ по синему прямоугольнику — начать/закончить перетаскивание
#  • Пробел — отправить пользовательское событие FIRE
#  • Колёсико мыши — менять толщину рамки
#  • T — включить/выключить таймер SPAWN (каждую секунду)
#
# ЗАДАЧИ (TODO):
# 1) Обработай KEYDOWN/KEYUP: по KEYDOWN K_SPACE — постить USEREVENT_FIRE в очередь.
# 2) Перетаскивание: запоминать смещение курсора относительно центра прямоугольника, двигать при MOUSEMOTION.
# 3) MOUSEWHEEL: изменять border_thickness в пределах 1..12.
# 4) Таймер: по клавише T переключать set_timer(SPAWN_EVENT, 1000).
# 5) Рисовать логи логов событий на экране (последние 6 строк).

pygame.init()
W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 13 — События (starter)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

# Объект для перетаскивания
drag_rect = pygame.Rect(0, 0, 160, 100)
drag_rect.center = (W//2, H//2)
dragging = False
drag_offset = pygame.Vector2(0, 0)
border_thickness = 4

# Пользовательские события
USEREVENT_FIRE  = pygame.USEREVENT + 1
USEREVENT_SPAWN = pygame.USEREVENT + 2

spawn_enabled = False
logs: list[str] = []

def log(msg: str) -> None:
    logs.append(msg)
    if len(logs) > 6:
        del logs[0]

def toggle_spawn_timer():
    global spawn_enabled
    spawn_enabled = not spawn_enabled
    pygame.time.set_timer(USEREVENT_SPAWN, 1000 if spawn_enabled else 0)
    log(f'SPAWN timer: {"ON" if spawn_enabled else "OFF"}')

running = True
while running:
    dt = clock.tick(60) / 1000.0

    # Опрос состояний (пример): удержание клавиш стрелок — двигаем прямоугольник плавно
    keys = pygame.key.get_pressed()
    vx = (1 if keys[pygame.K_RIGHT] else 0) - (1 if keys[pygame.K_LEFT] else 0)
    vy = (1 if keys[pygame.K_DOWN] else 0) - (1 if keys[pygame.K_UP] else 0)
    if vx or vy:
        v = pygame.Vector2(vx, vy)
        if v.length_squared() > 0: v = v.normalize()
        drag_rect.move_ip(v.x * 240 * dt, v.y * 240 * dt)
        drag_rect.clamp_ip(screen.get_rect())

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # TODO-1: KEYDOWN/KEYUP + постинг события FIRE
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            if event.key == pygame.K_SPACE:
                pygame.event.post(pygame.event.Event(USEREVENT_FIRE, {'power': 10}))
                log('post: FIRE')
            if event.key == pygame.K_t:
                toggle_spawn_timer()

        # TODO-2: перетаскивание мышью
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and drag_rect.collidepoint(event.pos):
            dragging = True
            drag_offset = pygame.Vector2(event.pos) - pygame.Vector2(drag_rect.center)
            log('mouse: drag start')
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if dragging: log('mouse: drag end')
            dragging = False
        if event.type == pygame.MOUSEMOTION and dragging:
            drag_rect.center = (event.pos[0] - drag_offset.x, event.pos[1] - drag_offset.y)

        # TODO-3: колесо мыши
        if event.type == pygame.MOUSEWHEEL:
            border_thickness = max(1, min(12, border_thickness + event.y))
            log(f'wheel: {event.y} thickness={border_thickness}')

        # TODO-4: таймеры и пользовательские события
        if event.type == USEREVENT_SPAWN:
            log('SPAWN tick')
        if event.type == USEREVENT_FIRE:
            log(f'FIRE! power={getattr(event, "power", "?")}')

    # Рендер
    screen.fill((24, 26, 32))
    pygame.draw.rect(screen, (70, 120, 210), drag_rect, 0, border_radius=12)
    pygame.draw.rect(screen, (220, 230, 255), drag_rect, border_thickness, border_radius=12)

    # вывод логов и подсказок
    hint = [
        'ESC — выход | T — вкл/выкл таймер SPAWN',
        'SPACE — post FIRE | колесо мыши — толщина рамки',
        'Стрелки — плавный сдвиг (опрос состояний) | ЛКМ — перетаскивание'
    ]
    for i, msg in enumerate(hint + logs[-6:]):
        screen.blit(font.render(msg, True, (235,235,240)), (10, 10 + i*20))

    pygame.display.flip()

pygame.quit()
sys.exit()
