# -*- coding: utf-8 -*-
import pygame, sys

# Модуль 12 — Закрытие окна (starter)
# Цели:
# - Корректно обрабатывать закрытие окна через крестик (QUIT).
# - Добавить выход по ESC.
# - Понять разницу между break, return, pygame.quit(), sys.exit().
# - (доп.) Диалог подтверждения выхода.

pygame.init()
W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 12 — Закрытие окна (starter)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 24)

background_color = (26, 28, 34)

# Флаг основного цикла
is_running: bool = True

# (доп.) Флаг показа диалога подтверждения
show_confirm: bool = False

def draw_ui():
    lines = [
        'ESC — выйти',
        'Закрытие по крестику — событие QUIT',
        'Дополнительно: диалог подтверждения (SPACE — да, N — нет)'
    ]
    for i, msg in enumerate(lines):
        screen.blit(font.render(msg, True, (235,235,240)), (12, 12 + i*22))

while is_running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        # TODO-1: обработка закрытия окна (QUIT)
        if event.type == pygame.QUIT:
            is_running = False

        # TODO-2: выход по ESC
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            # В простом варианте — сразу выходим
            is_running = False
            # В продвинутом варианте — спросить подтверждение:
            # show_confirm = True

        # TODO-3 (необязательно): подтверждение выхода
        if show_confirm and event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:   # да
                is_running = False
            if event.key == pygame.K_n:       # нет
                show_confirm = False

    # Рендер
    screen.fill(background_color)
    draw_ui()

    if show_confirm:
        # Рисуем простой диалог
        import pygame as pg
        box = pg.Rect(0, 0, 420, 140)
        box.center = (W//2, H//2)
        pg.draw.rect(screen, (40, 46, 62), box, 0, border_radius=12)
        pg.draw.rect(screen, (120, 160, 220), box, 2, border_radius=12)
        txt1 = font.render('Выйти из приложения?', True, (235,235,240))
        txt2 = font.render('SPACE — да, N — нет', True, (200,210,220))
        screen.blit(txt1, (box.x + 24, box.y + 28))
        screen.blit(txt2, (box.x + 24, box.y + 68))

    pygame.display.flip()

# Корректное завершение
pygame.quit()
sys.exit()
