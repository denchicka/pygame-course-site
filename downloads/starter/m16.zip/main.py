# -*- coding: utf-8 -*-
import pygame, sys, random

# Модуль 16 — Спрайты и группы (starter)
# Цели:
# - Базовый класс pygame.sprite.Sprite (поля image, rect)
# - Группы: Group, GroupSingle; методы add/remove/sprites/draw/update
# - Столкновения: spritecollide, groupcollide
# - Уничтожение спрайта: kill()
#
# ЗАДАЧИ (ищи TODO):
# 1) Сделай класс Player(Sprite) с управлением стрелками и ограничением экрана.
# 2) Сделай класс Enemy(Sprite), который двигается и отскакивает от стен.
# 3) Размести 8 врагов в случайных позициях, добавь в группу enemies.
# 4) Столкновения: если игрок касается врага — покрась игрока в красный на 0.3с.
# 5) Добавь монеты (Coin) и сбор: при столкновении монета удаляется (kill), счёт +1.

pygame.init()
W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 16 — Спрайты (starter)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

BG = (24, 26, 32)

class Player(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image_normal = pygame.Surface((48, 48), pygame.SRCALPHA)
        self.image_normal.fill((90, 170, 250))
        pygame.draw.rect(self.image_normal, (240,240,255), self.image_normal.get_rect(), 2, border_radius=8)
        self.image_hit = pygame.Surface((48, 48), pygame.SRCALPHA)
        self.image_hit.fill((230, 90, 90))
        pygame.draw.rect(self.image_hit, (240,240,255), self.image_hit.get_rect(), 2, border_radius=8)
        self.image = self.image_normal
        self.rect = self.image.get_rect(center=pos)

        self.speed = 320.0
        self.hit_timer = 0.0

    def update(self, dt: float):
        keys = pygame.key.get_pressed()
        vx = (1 if keys[pygame.K_RIGHT] else 0) - (1 if keys[pygame.K_LEFT] else 0)
        vy = (1 if keys[pygame.K_DOWN] else 0) - (1 if keys[pygame.K_UP] else 0)
        v = pygame.Vector2(vx, vy)
        if v.length_squared() > 0:
            v = v.normalize()
            self.rect.move_ip(v.x * self.speed * dt, v.y * self.speed * dt)
        self.rect.clamp_ip(screen.get_rect())

        # индикация получения урона
        if self.hit_timer > 0:
            self.hit_timer -= dt
            self.image = self.image_hit
        else:
            self.image = self.image_normal

class Enemy(pygame.sprite.Sprite):
    def __init__(self, pos, vel):
        super().__init__()
        self.image = pygame.Surface((36, 36), pygame.SRCALPHA)
        self.image.fill((255, 190, 60))
        pygame.draw.rect(self.image, (40,40,40), self.image.get_rect(), 2, border_radius=8)
        self.rect = self.image.get_rect(center=pos)
        self.vel = pygame.Vector2(vel)

    def update(self, dt: float):
        self.rect.x += int(self.vel.x * dt)
        self.rect.y += int(self.vel.y * dt)
        # отскок
        if self.rect.left < 0 or self.rect.right > W:
            self.vel.x *= -1; self.rect.clamp_ip(screen.get_rect())
        if self.rect.top < 0 or self.rect.bottom > H:
            self.vel.y *= -1; self.rect.clamp_ip(screen.get_rect())

class Coin(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface((20, 20), pygame.SRCALPHA)
        pygame.draw.circle(self.image, (120,220,140), (10,10), 10)
        pygame.draw.circle(self.image, (240,255,245), (10,10), 10, 2)
        self.rect = self.image.get_rect(center=pos)

    def update(self, dt: float):
        pass  # монета статична

# Группы
all_sprites = pygame.sprite.Group()
player_group = pygame.sprite.GroupSingle()
enemies = pygame.sprite.Group()
coins = pygame.sprite.Group()

# Игрок
player = Player((W//2, H//2))
player_group.add(player); all_sprites.add(player)

# Враги
for _ in range(8):
    pos = (random.randint(60, W-60), random.randint(60, H-60))
    vel = (random.choice([-200, -140, 140, 200]), random.choice([-220, -160, 160, 220]))
    e = Enemy(pos, vel)
    enemies.add(e); all_sprites.add(e)

# Монеты
for _ in range(6):
    c = Coin((random.randint(40, W-40), random.randint(40, H-40)))
    coins.add(c); all_sprites.add(c)

score = 0

running = True
while running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT: running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: running = False

    # Обновление
    all_sprites.update(dt)

    # Столкновение игрока с врагами (TODO-4: подсветить игрока)
    hit_list = pygame.sprite.spritecollide(player, enemies, False)
    if hit_list:
        player.hit_timer = 0.3  # 0.3 секунды показываем "удар"

    # Сбор монет (TODO-5: kill + счёт)
    got = pygame.sprite.spritecollide(player, coins, dokill=True)
    if got:
        score += len(got)

    # Рендер
    screen.fill(BG)
    all_sprites.draw(screen)

    ui = [
        'Стрелки — движение | ESC — выход',
        f'Враги: {len(enemies)} | Монеты: {len(coins)} | Счёт: {score}'
    ]
    for i, msg in enumerate(ui):
        screen.blit(font.render(msg, True, (235,235,240)), (10, 10 + i*20))

    pygame.display.flip()

pygame.quit()
sys.exit()
