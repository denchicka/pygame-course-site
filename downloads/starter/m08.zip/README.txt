Модуль 8 — Rect: атрибуты и методы

Ключевые атрибуты Rect:
- x, y, w, h; left, top, right, bottom;
- center, centerx, centery; size;
- topleft, topright, bottomleft, bottomright; mid* (midtop, midbottom, midleft, midright).

Полезные методы:
- move/move_ip, inflate/inflate_ip, clamp/clamp_ip,
- colliderect/ collidepoint, union/clip.

Практика:
- Движение по стрелкам с dt, ограничение экрана, resize клавишами I/O,
- позиционирование через якоря (center/topright), обработка клика.

Запуск: python main.py
