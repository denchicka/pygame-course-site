import pygame, sys
# Модуль 8 — Rect: атрибуты и методы (starter)
# ЗАДАЧИ (ищи TODO ниже):
# 1) Создай прямоугольник игрока 80x50, выровняй по центру экрана через rect.center.
# 2) Двигай игрока стрелками ← → ↑ ↓ на 200 пикс/сек (используй dt и move_ip).
# 3) Ограничь игрока границами экрана через clamp_ip.
# 4) Нарисуй «цель» (rect 120x80) в правом верхнем углу: rect.topright = (screen_width-20, 20).
# 5) Подсвети столкновение: если player.colliderect(target) — обводка зелёная, иначе красная.
# 6) По клику мышью перемести игрока так, чтобы центр совпал с курсором (rect.center).
# 7) Клавиша I — увеличить размер игрока через inflate_ip(20, 10), клавиша O — уменьшить.
# 8) Покажи на экране ключевые атрибуты: left, top, right, bottom, center, size.

pygame.init()

screen_width, screen_height = 900, 600
screen_surface = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Модуль 8 — Rect (starter)')

clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

background_color = (24, 26, 32)
grid_color = (45, 50, 62)
ok_color = (80, 200, 120)
bad_color = (220, 90, 90)
ui_color = (235, 235, 240)

# Игрок (TODO-1: центрирование)
player_rect = pygame.Rect(0, 0, 80, 50)
player_rect.center = (screen_width // 2, screen_height // 2)

# Цель (TODO-4: top/right позиционирование)
target_rect = pygame.Rect(0, 0, 120, 80)
target_rect.topright = (screen_width - 20, 20)

speed = 200.0  # пикс/сек

def draw_grid(surface: pygame.Surface, step: int = 50) -> None:
    w, h = surface.get_width(), surface.get_height()
    for x in range(0, w, step):
        pygame.draw.line(surface, grid_color, (x, 0), (x, h), 1)
    for y in range(0, h, step):
        pygame.draw.line(surface, grid_color, (0, y), (w, y), 1)

is_running = True
while is_running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_running = False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # TODO-6: переместить центр игрока в позицию мыши
            player_rect.center = event.pos
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_i:
                # TODO-7: увеличить
                player_rect.inflate_ip(20, 10)
            if event.key == pygame.K_o:
                # TODO-7: уменьшить
                player_rect.inflate_ip(-20, -10)

    # Движение (TODO-2)
    keys = pygame.key.get_pressed()
    dx = (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * speed * dt
    dy = (keys[pygame.K_DOWN] - keys[pygame.K_UP]) * speed * dt
    player_rect.move_ip(dx, dy)

    # Ограничение по экрану (TODO-3)
    screen_bounds = screen_surface.get_rect()
    player_rect.clamp_ip(screen_bounds)

    # Столкновение (TODO-5)
    collides = player_rect.colliderect(target_rect)

    # Рендер
    screen_surface.fill(background_color)
    draw_grid(screen_surface, 50)

    # цель
    pygame.draw.rect(screen_surface, (80, 120, 220), target_rect, 2, border_radius=8)

    # игрок
    border_color = ok_color if collides else bad_color
    pygame.draw.rect(screen_surface, (200, 200, 220), player_rect, 0, border_radius=10)
    pygame.draw.rect(screen_surface, border_color, player_rect, 3, border_radius=10)

    # атрибуты
    info = [
        f'player: left={player_rect.left} top={player_rect.top} right={player_rect.right} bottom={player_rect.bottom}',
        f'center={player_rect.center} size={player_rect.size} topleft={player_rect.topleft} bottomright={player_rect.bottomright}',
        f'collides={collides}  |  I/O: resize,  click: move center'
    ]
    for i, msg in enumerate(info):
        screen_surface.blit(font.render(msg, True, ui_color), (10, 10 + i*18))

    pygame.display.flip()

pygame.quit()
sys.exit()
