# -*- coding: utf-8 -*-
# Модуль 0 — Подготовка окружения (starter)
# ЗАДАНИЯ:
# 1) Поменяй размер окна на 900x600.
# 2) Поменяй заголовок окна (set_caption).
# 3) Введи переменную background_color и используй её в fill().
# 4) Добавь обработку закрытия окна (QUIT).
# 5) Убедись, что pygame.display.flip() вызывается каждый кадр.

import pygame, sys

pygame.init()

screen_surface = pygame.display.set_mode((800, 600))
pygame.display.set_caption('PyGame — стартовый проект')

is_running: bool = True

while is_running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_running = False

    screen_surface.fill((230, 230, 240))
    pygame.display.flip()

pygame.quit()
sys.exit()
