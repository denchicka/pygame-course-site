import pygame, sys
# Модуль 8 — Rect: атрибуты и методы (final)

pygame.init()

screen_width, screen_height = 900, 600
screen_surface = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Модуль 8 — Rect (final)')

clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

background_color = (24, 26, 32)
grid_color = (45, 50, 62)
ok_color = (80, 200, 120)
bad_color = (220, 90, 90)
ui_color = (235, 235, 240)

# Игрок по центру
player_rect = pygame.Rect(0, 0, 80, 50)
player_rect.center = (screen_width // 2, screen_height // 2)

# Цель в правом верхнем углу с отступом
target_rect = pygame.Rect(0, 0, 120, 80)
target_rect.topright = (screen_width - 20, 20)

speed = 200.0  # пикс/сек

def draw_grid(surface: pygame.Surface, step: int = 50) -> None:
    w, h = surface.get_width(), surface.get_height()
    for x in range(0, w, step):
        pygame.draw.line(surface, grid_color, (x, 0), (x, h), 1)
    for y in range(0, h, step):
        pygame.draw.line(surface, grid_color, (0, y), (w, y), 1)

is_running = True
while is_running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_running = False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            player_rect.center = event.pos
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_i:
                player_rect.inflate_ip(20, 10)
            if event.key == pygame.K_o:
                player_rect.inflate_ip(-20, -10)

    keys = pygame.key.get_pressed()
    dx = (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * speed * dt
    dy = (keys[pygame.K_DOWN] - keys[pygame.K_UP]) * speed * dt
    player_rect.move_ip(dx, dy)

    # ограничение области
    player_rect.clamp_ip(screen_surface.get_rect())

    collides = player_rect.colliderect(target_rect)

    screen_surface.fill(background_color)
    draw_grid(screen_surface, 50)

    # цель
    pygame.draw.rect(screen_surface, (80, 120, 220), target_rect, 2, border_radius=8)

    # игрок
    pygame.draw.rect(screen_surface, (200, 200, 220), player_rect, 0, border_radius=10)
    pygame.draw.rect(screen_surface, (80, 200, 120) if collides else (220, 90, 90), player_rect, 3, border_radius=10)

    # вспомогательные маркеры
    pygame.draw.circle(screen_surface, (255, 220, 120), player_rect.center, 3)     # центр
    pygame.draw.circle(screen_surface, (180, 180, 255), player_rect.topleft, 3)    # левый верх
    pygame.draw.circle(screen_surface, (180, 180, 255), player_rect.bottomright, 3)

    # вывод атрибутов
    info = [
        f'player: x={player_rect.x} y={player_rect.y} w={player_rect.w} h={player_rect.h}',
        f'left={player_rect.left} top={player_rect.top} right={player_rect.right} bottom={player_rect.bottom}',
        f'center={player_rect.center} size={player_rect.size} midtop={player_rect.midtop} midright={player_rect.midright}',
        f'collides={collides}  |  move: arrows  |  I/O: resize  |  click: center move'
    ]
    for i, msg in enumerate(info):
        screen_surface.blit(font.render(msg, True, ui_color), (10, 10 + i*18))

    pygame.display.flip()

pygame.quit()
sys.exit()
