import pygame, sys, math

# Модуль 9 — Движение фигур: прямоугольники и круги (final)

pygame.init()

W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 9 — Движение (final)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

player = pygame.Rect(0, 0, 100, 60)
player.center = (W//2, H//2)
PLAYER_SPEED = 280.0

ball_pos = pygame.Vector2(200, 120)
ball_vel = pygame.Vector2(220, 160)
BALL_R = 22

dragging = False
drag_offset = pygame.Vector2(0, 0)

def move_player(rect: pygame.Rect, dt: float) -> None:
    keys = pygame.key.get_pressed()
    v = pygame.Vector2(
        (1 if keys[pygame.K_RIGHT] else 0) - (1 if keys[pygame.K_LEFT] else 0),
        (1 if keys[pygame.K_DOWN] else 0) - (1 if keys[pygame.K_UP] else 0)
    )
    if v.length_squared() > 0:
        v = v.normalize()
        rect.move_ip(v.x * PLAYER_SPEED * dt, v.y * PLAYER_SPEED * dt)

def bounce_ball(pos: pygame.Vector2, vel: pygame.Vector2, r: int, bounds: pygame.Rect, damp: float = 1.0) -> None:
    pos += vel * dt
    # отскок с демпфированием (damp=1.0 — без потерь)
    if pos.x - r < bounds.left:
        pos.x = bounds.left + r; vel.x *= -damp
    if pos.x + r > bounds.right:
        pos.x = bounds.right - r; vel.x *= -damp
    if pos.y - r < bounds.top:
        pos.y = bounds.top + r; vel.y *= -damp
    if pos.y + r > bounds.bottom:
        pos.y = bounds.bottom - r; vel.y *= -damp

def draw_axes(surface: pygame.Surface, step: int = 50) -> None:
    w, h = surface.get_width(), surface.get_height()
    for x in range(0, w, step):
        pygame.draw.line(surface, (44,48,58), (x, 0), (x, h), 1)
    for y in range(0, h, step):
        pygame.draw.line(surface, (44,48,58), (0, y), (w, y), 1)

running = True
while running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if player.collidepoint(event.pos):
                dragging = True
                drag_offset = pygame.Vector2(event.pos) - pygame.Vector2(player.center)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            dragging = False
        elif event.type == pygame.MOUSEMOTION and dragging:
            player.center = (event.pos[0] - drag_offset.x, event.pos[1] - drag_offset.y)

    move_player(player, dt)
    player.clamp_ip(screen.get_rect())

    bounce_ball(ball_pos, ball_vel, BALL_R, screen.get_rect(), damp=1.0)

    screen.fill((22, 24, 30))
    draw_axes(screen, 50)

    pygame.draw.rect(screen, (200, 200, 220), player, 0, border_radius=10)
    pygame.draw.rect(screen, (90, 180, 255), player, 3, border_radius=10)
    pygame.draw.circle(screen, (255, 190, 60), (int(ball_pos.x), int(ball_pos.y)), BALL_R)

    info = [
        f'player center={player.center} | speed={PLAYER_SPEED} px/s',
        f'ball pos=({int(ball_pos.x)}, {int(ball_pos.y)}) vel=({int(ball_vel.x)}, {int(ball_vel.y)})',
        'Управление: стрелки (движение), ЛКМ — перетаскивание прямоугольника'
    ]
    for i, msg in enumerate(info):
        screen.blit(font.render(msg, True, (235,235,240)), (10, 10 + i*18))

    pygame.display.flip()

pygame.quit()
sys.exit()
