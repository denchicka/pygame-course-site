# -*- coding: utf-8 -*-
import pygame, sys, os

# Модуль 11 — Звук (final)
# Фоновая музыка (loop), пауза/стоп/затухание, громкость; эффекты Sound на отдельных каналах.

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()

W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 11 — Звук (final)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 22)

try:
    pygame.mixer.init()
except Exception as e:
    print('Ошибка mixer.init():', e)

MUSIC = 'assets/sounds/music.ogg'
SFX = {
    '1': 'assets/sounds/click.wav',
    '2': 'assets/sounds/jump.wav',
    '3': 'assets/sounds/explosion.wav',
}

music_volume = 0.6
sfx_volume = 0.8

# Загрузка музыки
def load_music(path: str) -> bool:
    try:
        pygame.mixer.music.load(path)
        pygame.mixer.music.set_volume(music_volume)
        return True
    except Exception as e:
        print('music load failed:', e)
        return False

# Загрузка SFX
def load_sfx(paths: dict[str,str]) -> dict[str, pygame.mixer.Sound]:
    out = {}
    for k, p in paths.items():
        try:
            snd = pygame.mixer.Sound(p)
            snd.set_volume(sfx_volume)
            out[k] = snd
        except Exception as e:
            print(f'sfx load failed for {p}:', e)
    return out

has_music = load_music(MUSIC)
sfx = load_sfx(SFX)

pygame.mixer.set_num_channels(16)

def vol_clamp(x: float) -> float: return max(0.0, min(1.0, x))

running = True
while running:
    dt = clock.tick(60) / 1000.0
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            # Музыка: play/pause/stop/fadeout
            if event.key == pygame.K_m and has_music:
                # toggle play/stop
                if pygame.mixer.music.get_busy():
                    pygame.mixer.music.stop()
                else:
                    pygame.mixer.music.play(-1)
            if event.key == pygame.K_p:
                pygame.mixer.music.pause() if pygame.mixer.music.get_busy() else pygame.mixer.music.unpause()
            if event.key == pygame.K_s:
                pygame.mixer.music.stop()
            if event.key == pygame.K_f:
                pygame.mixer.music.fadeout(1200)  # 1.2 c

            # Музыка: громкость
            if event.key in (pygame.K_EQUALS, pygame.K_PLUS):
                music_volume = vol_clamp(music_volume + 0.05); pygame.mixer.music.set_volume(music_volume)
            if event.key == pygame.K_MINUS:
                music_volume = vol_clamp(music_volume - 0.05); pygame.mixer.music.set_volume(music_volume)

            # SFX: громкость
            if event.key == pygame.K_LEFTBRACKET:
                sfx_volume = vol_clamp(sfx_volume - 0.05)
                for snd in sfx.values(): snd.set_volume(sfx_volume)
            if event.key == pygame.K_RIGHTBRACKET:
                sfx_volume = vol_clamp(sfx_volume + 0.05)
                for snd in sfx.values(): snd.set_volume(sfx_volume)

            # Воспроизведение SFX на свободном канале
            if event.unicode in sfx:
                ch = pygame.mixer.find_channel(True)
                if ch: ch.play(sfx[event.unicode])

    # Рендер статуса
    screen.fill((26,28,34))
    y = 10
    def line(msg):
        nonlocal y
        screen.blit(font.render(msg, True, (235,235,240)), (10, y))
        y += 22

    line('M — play/stop music, P — pause/unpause, S — stop, F — fadeout')
    line('[ / ] — SFX volume | +/- — music volume | 1/2/3 — play SFX')
    line(f'music: {"busy" if pygame.mixer.music.get_busy() else "stopped"} | music volume={music_volume:.2f} | sfx volume={sfx_volume:.2f}')
    line(f'loaded sfx: {", ".join(sorted(sfx.keys())) or "none"}')

    pygame.display.flip()

pygame.quit()
sys.exit()
