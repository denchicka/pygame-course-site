Модуль 11 — Звук (pygame.mixer)

Структура:
assets/
  sounds/
    music.ogg
    click.wav
    jump.wav
    explosion.wav

Покрываем:
- mixer.pre_init/init, set_num_channels
- Фоновая музыка: mixer.music.load, play(-1), pause/unpause, stop, fadeout, set_volume
- Эффекты: Sound(...), set_volume, проигрывание на свободном канале find_channel(True)
- Управление громкостью с клавиатуры, отображение статуса

Управление:
- M — старт/стоп музыки
- P — пауза/продолжить
- S — стоп
- F — затухание (fadeout)
- [+]/[-] — громкость музыки
- [ / ] — громкость SFX
- 1/2/3 — воспроизвести разные эффекты

Запуск:
python main.py
