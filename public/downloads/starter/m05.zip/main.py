import pygame, sys

pygame.init()

screen_width, screen_height = 900, 600
screen_surface = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Модуль 5 — Фигуры (starter)')

clock = pygame.time.Clock()
background_color = (24, 26, 32)

# TODO-1: Нарисуй линию от (50,50) до (300,120) шириной 5 и цветом (0, 120, 220).
# TODO-2: Нарисуй прямоугольник рамкой (x=400, y=80, w=200, h=120) шириной 3.
# TODO-3: Нарисуй круг (cx=200, cy=350, r=60) залитый цветом (50, 180, 90).
# TODO-4: Нарисуй эллипс в прямоугольнике (x=500, y=300, w=220, h=120) толщиной 4.
# TODO-5: Нарисуй многоугольник с вершинами [(100,500),(160,460),(220,500),(200,560),(120,560)] залитым.
# TODO-6: Поэкспериментируй с параметром width=0 (заливка) и >0 (контур).

is_running = True
while is_running:
    dt = clock.tick(60) / 1000.0
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_running = False

    screen_surface.fill(background_color)

    # === РИСОВАНИЕ (добавляй сюда) ===
    # pygame.draw.line(screen_surface, (0, 120, 220), (50, 50), (300, 120), 5)
    # pygame.draw.rect(screen_surface, (220, 70, 70), (400, 80, 200, 120), 3, border_radius=12)
    # pygame.draw.circle(screen_surface, (50, 180, 90), (200, 350), 60, 0)
    # pygame.draw.ellipse(screen_surface, (180, 120, 255), (500, 300, 220, 120), 4)
    # pygame.draw.polygon(screen_surface, (255, 200, 0), [(100,500),(160,460),(220,500),(200,560),(120,560)], 0)

    pygame.display.flip()

pygame.quit()
sys.exit()
