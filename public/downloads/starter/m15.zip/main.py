# -*- coding: utf-8 -*-
import pygame, sys, time

# Модуль 15 — Ввод: клавиатура, мышь, колесо, текст, модификаторы, перетаскивание (starter)
# Цели:
# - Разница KEYDOWN/KEYUP vs get_pressed() для удержания.
# - Модификаторы: Ctrl/Shift/Alt (event.mod & KMOD_*).
# - Текстовый ввод: pygame.TEXTINPUT (раскладка/символы), обработка BACKSPACE/ENTER.
# - Клики мышью, двойной клик (по времени), перетаскивание с зажатой ЛКМ.
# - Колесо мыши для масштабирования выбранного объекта.
#
# Объекты: набор прямоугольников; можно выделить, перетаскивать, менять размер колесом.
# Горячие клавиши:
#   ESC — выход
#   DEL — удалить выбранный
#   Ctrl+D — дублировать выбранный
#   Ctrl+A — выбрать все
#   Стрелки — двигать выбранный на 5 px (Shift — на 20 px)
#   F2 — начать ввод текста (имя объекта), ENTER — закончить, BACKSPACE — удалить символ
# Мышь:
#   ЛКМ — выбрать, ЛКМ+перетаскивание — двигать; двойной клик — начать ввод имени
#   Колёсико — изменить размер (радиус скругления/ширину/высоту)
#
# TODO отметки смотри ниже.

pygame.init()
W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 15 — Ввод (starter)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

# Модель
class Box:
    def __init__(self, x, y, w=120, h=80, name='Box'):
        self.rect = pygame.Rect(x, y, w, h)
        self.name = name
        self.color = (80, 140, 220)
        self.selected = False

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect, 0, border_radius=10)
        pygame.draw.rect(surface, (235, 240, 255) if self.selected else (40, 60, 90), self.rect, 2, border_radius=10)
        label = font.render(self.name, True, (240, 240, 245))
        surface.blit(label, (self.rect.x + 8, self.rect.y + 6))

boxes = [
    Box(120, 120, name='A'),
    Box(360, 180, name='B'),
    Box(600, 320, name='C'),
]

dragging = False
drag_offset = pygame.Vector2(0, 0)

input_mode = False   # режим текстового ввода для выбранного
input_target = None
double_click_ms = 250
last_click_time = 0

def select_one_at(pos):
    # TODO: выделять верхний по z (правее в списке)
    for b in reversed(boxes):
        if b.rect.collidepoint(pos):
            for x in boxes: x.selected = False
            b.selected = True
            return b
    # вне объектов — снять выделение
    for x in boxes: x.selected = False
    return None

running = True
while running:
    dt = clock.tick(60) / 1000.0

    # Удержание: стрелки двигают выбранный
    keys = pygame.key.get_pressed()
    move = pygame.Vector2(
        (1 if keys[pygame.K_RIGHT] else 0) - (1 if keys[pygame.K_LEFT] else 0),
        (1 if keys[pygame.K_DOWN] else 0) - (1 if keys[pygame.K_UP] else 0),
    )
    if move.length_squared() > 0:
        step = 5
        if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]:
            step = 20
        for b in boxes:
            if b.selected:
                b.rect.move_ip(move.x * step, move.y * step)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # --- КЛАВИАТУРА (разовые события) ---
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

            mods = pygame.key.get_mods()
            # Удаление
            if event.key == pygame.K_DELETE:
                # TODO: удалить выбранные
                boxes[:] = [b for b in boxes if not b.selected]

            # Дублирование Ctrl+D
            if (mods & pygame.KMOD_CTRL) and event.key == pygame.K_d:
                for b in list(boxes):
                    if b.selected:
                        nb = Box(b.rect.x + 16, b.rect.y + 16, b.rect.w, b.rect.h, b.name + '_copy')
                        boxes.append(nb)

            # Выделить всё Ctrl+A
            if (mods & pygame.KMOD_CTRL) and event.key == pygame.K_a:
                for b in boxes: b.selected = True

            # Переименовать F2 — включить режим ввода
            if event.key == pygame.K_F2:
                for b in boxes:
                    if b.selected:
                        input_mode = True
                        input_target = b
                        break

        # Текстовый ввод
        if event.type == pygame.TEXTINPUT and input_mode and input_target:
            # TODO: добавить символы к имени
            input_target.name += event.text

        if event.type == pygame.KEYDOWN and input_mode and input_target:
            if event.key == pygame.K_BACKSPACE:
                # TODO: удаление символа
                input_target.name = input_target.name[:-1]
            if event.key == pygame.K_RETURN:
                input_mode = False
                input_target = None

        # --- МЫШЬ ---
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                now = pygame.time.get_ticks()
                double = (now - last_click_time) <= double_click_ms
                last_click_time = now

                target = select_one_at(event.pos)  # TODO: реализовано выше
                # двойной клик — сразу режим ввода
                if target and double:
                    input_mode = True
                    input_target = target

                if target:
                    dragging = True
                    drag_offset = pygame.Vector2(event.pos) - pygame.Vector2(target.rect.topleft)

            # Колесо — масштабирование
            if event.button == 4:  # wheel up
                for b in boxes:
                    if b.selected:
                        b.rect.inflate_ip(10, 6)
            if event.button == 5:  # wheel down
                for b in boxes:
                    if b.selected:
                        b.rect.inflate_ip(-10, -6)

        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            dragging = False

        if event.type == pygame.MOUSEMOTION and dragging:
            # TODO: перетаскивание выбранного
            for b in boxes:
                if b.selected:
                    new_pos = pygame.Vector2(event.pos) - drag_offset
                    b.rect.topleft = (int(new_pos.x), int(new_pos.y))

    # Рендер
    screen.fill((24, 26, 32))
    for b in boxes:
        b.draw(screen)

    # UI подсказки
    tips = [
        'ЛКМ — выбрать/перетащить (двойной клик — переименование)',
        'Колесо — изменить размер | Стрелки — двинуть (Shift — быстрее)',
        'F2 — текстовый ввод имени (ENTER — завершить, BACKSPACE — стереть)',
        'Ctrl+D — дублировать, Ctrl+A — выбрать всё, DEL — удалить'
    ]
    for i, t in enumerate(tips):
        screen.blit(font.render(t, True, (235,235,240)), (10, 10 + i*20))

    if input_mode and input_target:
        cursor = font.render('▍', True, (255,220,120))
        screen.blit(cursor, (input_target.rect.x + 8 + font.size(input_target.name)[0] + 2, input_target.rect.y + 6))

    pygame.display.flip()

pygame.quit()
sys.exit()
