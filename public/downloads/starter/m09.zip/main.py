import pygame, sys, math
# Модуль 9 — Движение фигур: прямоугольники и круги (starter)
# ЗАДАЧИ (TODO):
# 1) Управление прямоугольником стрелками с учётом dt; скорость в пикс/сек.
# 2) Нормализация диагонали (чтобы по диагонали не было быстрее).
# 3) Отскок круга от стен (vx, vy меняют знак при ударе).
# 4) Перетаскивание мышью: зажми ЛКМ по прямоугольнику — перемещай.
# 5) Ограничение области: объекты не выходят за экран (clamp/проверка радиуса).
# 6) (необязательно) Трение: скорость прямоугольника постепенно уменьшается.

pygame.init()

W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 9 — Движение (starter)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

# Прямоугольник (игрок)
player = pygame.Rect(0, 0, 100, 60)
player.center = (W//2, H//2)
player_speed = 260.0  # пикс/сек
player_vel = pygame.Vector2(0, 0)  # для варианта с трением

# Круг (мяч)
ball_pos = pygame.Vector2(200, 120)
ball_vel = pygame.Vector2(220, 160)
ball_r = 22

dragging = False
drag_offset = pygame.Vector2(0, 0)

def move_player_with_arrows(rect: pygame.Rect, dt: float) -> None:
    keys = pygame.key.get_pressed()
    dirx = (1 if keys[pygame.K_RIGHT] else 0) - (1 if keys[pygame.K_LEFT] else 0)
    diry = (1 if keys[pygame.K_DOWN] else 0) - (1 if keys[pygame.K_UP] else 0)
    v = pygame.Vector2(dirx, diry)
    if v.length_squared() > 0:
        v = v.normalize()  # нормализация диагонали
        rect.move_ip(v.x * player_speed * dt, v.y * player_speed * dt)

def bounce_ball(pos: pygame.Vector2, vel: pygame.Vector2, r: int, bounds: pygame.Rect) -> None:
    pos += vel * dt
    if pos.x - r < bounds.left:
        pos.x = bounds.left + r; vel.x *= -1
    if pos.x + r > bounds.right:
        pos.x = bounds.right - r; vel.x *= -1
    if pos.y - r < bounds.top:
        pos.y = bounds.top + r; vel.y *= -1
    if pos.y + r > bounds.bottom:
        pos.y = bounds.bottom - r; vel.y *= -1

running = True
while running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if player.collidepoint(event.pos):
                dragging = True
                drag_offset = pygame.Vector2(event.pos) - pygame.Vector2(player.center)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            dragging = False
        elif event.type == pygame.MOUSEMOTION and dragging:
            # перетаскивание
            player.center = (event.pos[0] - drag_offset.x, event.pos[1] - drag_offset.y)

    # Управление клавишами
    move_player_with_arrows(player, dt)

    # Ограничение области
    player.clamp_ip(screen.get_rect())

    # Движение и отскок мяча
    bounce_ball(ball_pos, ball_vel, ball_r, screen.get_rect())

    # Отрисовка
    screen.fill((22, 24, 30))
    # сетка
    for x in range(0, W, 50):
        pygame.draw.line(screen, (44,48,58), (x, 0), (x, H), 1)
    for y in range(0, H, 50):
        pygame.draw.line(screen, (44,48,58), (0, y), (W, y), 1)

    pygame.draw.rect(screen, (200, 200, 220), player, 0, border_radius=10)
    pygame.draw.circle(screen, (255, 190, 60), (int(ball_pos.x), int(ball_pos.y)), ball_r)

    info = [
        'Управление: стрелки (движение), ЛКМ по прямоугольнику — перетаскивание',
        'Диагональ нормализована, есть отскок круга от стен'
    ]
    for i, msg in enumerate(info):
        screen.blit(font.render(msg, True, (235,235,240)), (10, 10 + i*18))

    pygame.display.flip()

pygame.quit()
sys.exit()
