import pygame, sys, math

# Модуль 7 — Объекты из фигур (prefab) — STARTER
# Цель: собирать сложные объекты из примитивов (draw) и группировать код в функции/классы.
# ЗАДАЧИ (ищи TODO):
# 1) Напиши функцию draw_house(surface, pos, scale), которая рисует домик из прямоугольников и треугольника (polygon).
# 2) Напиши функцию draw_tree(surface, pos, scale) — ствол (rect) + крона (несколько кругов).
# 3) Создай класс Car с методами update(dt) и draw(surface), машина движется по X и отскакивает.
# 4) Добавь слойность (order): фон → декор (деревья/дома) → динамика (машина/шар).
# 5) Сделай функцию draw_person(surface, pos, scale) — кружок‑голова, прямоугольник‑тело, линии‑руки/ноги.

pygame.init()

screen_width, screen_height = 900, 600
screen_surface = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Модуль 7 — Префабы (starter)')

clock = pygame.time.Clock()
background_color = (30, 32, 38)

def draw_house(surface: pygame.Surface, pos: tuple[int, int], scale: float = 1.0) -> None:
    # TODO: домик: основание (rect), крыша (polygon), дверь/окно (rect) — цвета на выбор
    x, y = pos
    w, h = int(120*scale), int(80*scale)
    base_rect = pygame.Rect(x, y, w, h)
    pygame.draw.rect(surface, (200, 160, 120), base_rect, 0)  # пример заливки
    # крыша — доделай
    # дверь/окна — доделай

def draw_tree(surface: pygame.Surface, pos: tuple[int, int], scale: float = 1.0) -> None:
    # TODO: ствол + крона из нескольких кругов
    x, y = pos
    pygame.draw.rect(surface, (110, 70, 40), (x, y, int(20*scale), int(60*scale)), 0)
    # крона — доделай (круги разного радиуса)

class Car:
    def __init__(self, x: float, y: float, color=(80, 160, 240)) -> None:
        self.x = x
        self.y = y
        self.color = color
        self.vx = 220.0  # пикс/сек
        self.width = 120
        self.height = 50

    def update(self, dt: float, bounds: pygame.Rect) -> None:
        # TODO: движение по X, отскоки от левого/правого края
        self.x += self.vx * dt
        if self.x + self.width > bounds.right:
            self.x = bounds.right - self.width
            self.vx *= -1
        if self.x < bounds.left:
            self.x = bounds.left
            self.vx *= -1

    def draw(self, surface: pygame.Surface) -> None:
        # TODO: корпус (rect со скруглением), колёса (круги), окна (rect)
        body = pygame.Rect(int(self.x), int(self.y), self.width, self.height)
        pygame.draw.rect(surface, self.color, body, 0, border_radius=10)
        # колёса/окна — доделай

def draw_scene_static(surface: pygame.Surface) -> None:
    # TODO: фоновые элементы (дома, деревья) — несколько вызовов функций с разными параметрами/масштабом
    draw_house(surface, (80, 360), 1.0)
    draw_tree(surface, (300, 360), 1.2)

def main() -> None:
    car = Car(200, 470)
    is_running = True
    while is_running:
        dt = clock.tick(60) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                is_running = False

        # ЛОГИКА
        car.update(dt, pygame.Rect(0, 0, screen_width, screen_height))

        # ОТРИСОВКА (порядок важен: фон → статика → динамика → UI)
        screen_surface.fill(background_color)
        draw_scene_static(screen_surface)
        car.draw(screen_surface)

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == '__main__':
    main()
