Модуль 5 — Фигуры (pygame.draw)

Покрываем:
- draw.line, draw.rect, draw.circle, draw.ellipse, draw.polygon, draw.arc
- цвет (R,G,B), прямоугольники (x,y,w,h), ширина линии (width), скругление (border_radius)
- заливка (width=0) vs контур (width>0)

Запуск:
python main.py

Советы:
- Координаты считаются от левого верхнего угла (0,0), X вправо, Y вниз.
- Сначала очищай фон (fill), затем рисуй фигуры, затем flip().
