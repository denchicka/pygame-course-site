import pygame, sys

pygame.init()

screen_width, screen_height = 900, 600
screen_surface = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Модуль 5 — Фигуры (final)')

clock = pygame.time.Clock()
background_color = (24, 26, 32)

is_running = True
while is_running:
    dt = clock.tick(60) / 1000.0
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_running = False

    screen_surface.fill(background_color)

    # Линия
    pygame.draw.line(screen_surface, (0, 120, 220), (50, 50), (300, 120), 5)

    # Прямоугольник (контур) + скругление углов
    pygame.draw.rect(screen_surface, (220, 70, 70), (400, 80, 200, 120), 3, border_radius=12)

    # Круг (заливка)
    pygame.draw.circle(screen_surface, (50, 180, 90), (200, 350), 60, 0)

    # Эллипс (контур)
    pygame.draw.ellipse(screen_surface, (180, 120, 255), (500, 300, 220, 120), 4)

    # Многоугольник (заливка)
    pygame.draw.polygon(screen_surface, (255, 200, 0), [(100,500),(160,460),(220,500),(200,560),(120,560)], 0)

    # Арка (дуга окружности) 0..180°
    pygame.draw.arc(screen_surface, (240, 240, 240), (650, 100, 140, 140), 0.0, 3.14159, 3)

    pygame.display.flip()

pygame.quit()
sys.exit()
