# -*- coding: utf-8 -*-
import pygame, sys, math, os

# Модуль 10 — Изображения (final)
# Покрыто: загрузка, convert_alpha, масштабирование, flip, rotozoom, движение, простая анимация.

pygame.init()
W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 10 — Изображения (final)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

def load_image(path: str, fallback_size=(80,60), fallback_color=(200,80,80)) -> pygame.Surface:
    try:
        return pygame.image.load(path).convert_alpha()
    except Exception:
        s = pygame.Surface(fallback_size, pygame.SRCALPHA)
        s.fill(fallback_color)
        pygame.draw.rect(s, (240,240,240), s.get_rect(), 2)
        return s

# --- Загрузка ассетов ---
bg = load_image('assets/bg.png', (W, H), (32, 36, 44))
player_png = load_image('assets/player.png', (80,60), (80,160,220))
ball_png = load_image('assets/ball.png', (48,48), (255,200,60))

# Дополнительно поддержим анимацию player из папки assets/player_frames/
player_frames: list[pygame.Surface] = []
for i in range(1, 5):  # пробуем кадры player_1.png..player_4.png
    p = Path := os.path.join('assets', 'player_frames', f'player_{i}.png')
    img = load_image(p, (80,60), (80,160,220))
    player_frames.append(img)
if not player_frames:
    player_frames = [player_png]

# Масштабирование фона
bg_scaled = pygame.transform.scale(bg, (W, H))

# --- Состояния ---
player_rect = player_frames[0].get_rect(center=(W//2, H-90))
PLAYER_SPEED = 280.0
facing = 1  # 1 вправо, -1 влево

ball_rect = ball_png.get_rect(center=(W//2, 120))
ball_angle = 0.0
BALL_ANGULAR_SPEED = 120.0  # градусов в секунду

frame_index = 0
frame_time = 0.0
FRAME_DURATION = 0.12

def handle_player(dt: float) -> None:
    global facing, player_rect
    keys = pygame.key.get_pressed()
    vx = (1 if keys[pygame.K_RIGHT] else 0) - (1 if keys[pygame.K_LEFT] else 0)
    vy = (1 if keys[pygame.K_DOWN] else 0) - (1 if keys[pygame.K_UP] else 0)
    v = pygame.Vector2(vx, vy)
    if v.length_squared() > 0:
        v = v.normalize()
        facing = 1 if v.x >= 0 else -1
        player_rect.move_ip(v.x * PLAYER_SPEED * dt, v.y * PLAYER_SPEED * dt)
        player_rect.clamp_ip(screen.get_rect())

def update_animation(dt: float) -> None:
    global frame_index, frame_time
    frame_time += dt
    if frame_time >= FRAME_DURATION:
        frame_time -= FRAME_DURATION
        frame_index = (frame_index + 1) % len(player_frames)

def draw_rotated(surface: pygame.Surface, image: pygame.Surface, center: tuple[int,int], angle_deg: float) -> None:
    rotated = pygame.transform.rotozoom(image, -angle_deg, 1.0)  # отрицательный, чтобы 0° — вправо, и рост по часовой
    rect = rotated.get_rect(center=center)
    surface.blit(rotated, rect)

running = True
while running:
    dt = clock.tick(60) / 1000.0
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
            player_rect.center = (W//2, H-90)
            ball_rect.center = (W//2, 120)
            ball_angle = 0.0

    # Логика
    handle_player(dt)
    update_animation(dt)
    ball_angle += BALL_ANGULAR_SPEED * dt

    # Рендер
    screen.fill((30,32,38))
    screen.blit(bg_scaled, (0,0))

    # Player: текущий кадр + отражение по направлению
    frame = player_frames[frame_index]
    if facing < 0:
        frame = pygame.transform.flip(frame, True, False)
    screen.blit(frame, frame.get_rect(center=player_rect.center))

    # Мяч: вращение
    draw_rotated(screen, ball_png, ball_rect.center, ball_angle)

    # Подсказки
    info = [
        'Стрелки — движение | R — сброс',
        f'Угол мяча: {ball_angle:0.1f}° (растёт на {BALL_ANGULAR_SPEED}°/с)',
        'Отражение игрока по направлению; поддержка анимации frames (assets/player_frames/player_*.png)'
    ]
    for i, msg in enumerate(info):
        screen.blit(font.render(msg, True, (235,235,240)), (10, 10 + i*18))

    pygame.display.flip()

pygame.quit()
sys.exit()
