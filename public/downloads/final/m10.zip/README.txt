Модуль 10 — Изображения (pygame.image + transform)

Структура ассетов:
assets/
  bg.png
  player.png
  ball.png
  player_frames/
    player_1.png
    player_2.png
    player_3.png
    player_4.png

Темы:
- pygame.image.load(...).convert_alpha() — прозрачность, быстрый blit;
- Масштабирование: transform.scale(surface, (W,H));
- Поворот/масштаб: transform.rotate / rotozoom (углы в градусах, положительные против часовой стрелки);
- Отражение: transform.flip(image, flip_x, flip_y);
- Rect для позиционирования: get_rect(center=...);
- Простая анимация по времени из списка кадров.

Подсказка по градусам:
0° — направление вправо, 90° — вниз, 180° — влево, 270° — вверх (если используешь cos/sin). Для изображений transform.rotate даёт положительный угол против часовой стрелки. Для «по часовой» — используй отрицательный угол или rotozoom(..., -angle, ...).

Запуск:
python main.py

Примечание:
Если нужных файлов нет, скрипт создаст цветные заглушки. Для корректной демонстрации положите png-файлы в папку assets/.
