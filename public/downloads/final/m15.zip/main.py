# -*- coding: utf-8 -*-
import pygame, sys

# Модуль 15 — Ввод: клавиатура, мышь, колесо, текст, модификаторы, перетаскивание (final)

pygame.init()
W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 15 — Ввод (final)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

class Box:
    def __init__(self, x, y, w=140, h=90, name='Box'):
        self.rect = pygame.Rect(x, y, w, h)
        self.name = name
        self.color = (80, 140, 220)
        self.selected = False

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect, 0, border_radius=12)
        pygame.draw.rect(surface, (235, 240, 255) if self.selected else (40, 60, 90), self.rect, 2, border_radius=12)
        label = font.render(self.name, True, (240, 240, 245))
        surface.blit(label, (self.rect.x + 8, self.rect.y + 6))

boxes = [Box(120, 120, name='A'), Box(360, 180, name='B'), Box(600, 320, name='C')]

def hit_top(pos):
    for b in reversed(boxes):
        if b.rect.collidepoint(pos):
            return b
    return None

def select_only(target):
    for b in boxes: b.selected = (b is target)

dragging = False
drag_offset = pygame.Vector2(0, 0)
active = None

input_mode = False
input_target = None
double_click_ms = 250
last_click = 0

running = True
while running:
    dt = clock.tick(60) / 1000.0

    # Удержание — стрелки с модификатором Shift
    keys = pygame.key.get_pressed()
    dx = (1 if keys[pygame.K_RIGHT] else 0) - (1 if keys[pygame.K_LEFT] else 0)
    dy = (1 if keys[pygame.K_DOWN] else 0) - (1 if keys[pygame.K_UP] else 0)
    step = 5 * (4 if (keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]) else 1)
    if dx or dy:
        for b in boxes:
            if b.selected:
                b.rect.move_ip(dx * step, dy * step)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            mods = pygame.key.get_mods()
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_DELETE:
                boxes[:] = [b for b in boxes if not b.selected]
            elif (mods & pygame.KMOD_CTRL) and event.key == pygame.K_d:
                # дублировать
                for b in list(boxes):
                    if b.selected:
                        nb = Box(b.rect.x + 16, b.rect.y + 16, b.rect.w, b.rect.h, b.name + '_copy')
                        nb.selected = True
                        b.selected = False
                        boxes.append(nb)
            elif (mods & pygame.KMOD_CTRL) and event.key == pygame.K_a:
                for b in boxes: b.selected = True
            elif event.key == pygame.K_F2:
                target = next((b for b in boxes if b.selected), None)
                if target:
                    input_mode = True; input_target = target

        # Текстовый ввод
        if event.type == pygame.TEXTINPUT and input_mode and input_target:
            input_target.name += event.text
        if event.type == pygame.KEYDOWN and input_mode and input_target:
            if event.key == pygame.K_BACKSPACE and len(input_target.name) > 0:
                input_target.name = input_target.name[:-1]
            if event.key in (pygame.K_RETURN, pygame.K_ESCAPE):
                input_mode = False; input_target = None

        # Мышь
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                now = pygame.time.get_ticks()
                double = (now - last_click) <= double_click_ms
                last_click = now

                active = hit_top(event.pos)
                if active:
                    select_only(active)
                    if double:
                        input_mode = True; input_target = active
                    dragging = True
                    drag_offset = pygame.Vector2(event.pos) - pygame.Vector2(active.rect.topleft)
                else:
                    # клик по пустому месту — снять выделение
                    for b in boxes: b.selected = False

            # колесо: масштаб выбранных
            if event.button == 4:
                for b in boxes:
                    if b.selected: b.rect.inflate_ip(10, 6)
            if event.button == 5:
                for b in boxes:
                    if b.selected: b.rect.inflate_ip(-10, -6)

        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            dragging = False; active = None

        if event.type == pygame.MOUSEMOTION and dragging and active:
            new_pos = pygame.Vector2(event.pos) - drag_offset
            active.rect.topleft = (int(new_pos.x), int(new_pos.y))

    # Рендер
    screen.fill((24, 26, 32))
    for b in boxes:
        b.draw(screen)

    tips = [
        'ЛКМ — выбрать/перетащить (двойной клик — переименование), Колесо — размер',
        'Стрелки — сдвиг (Shift быстрее) | Ctrl+D — дублировать | Ctrl+A — выбрать все | DEL — удалить',
        'F2/двойной клик — ввод имени, ENTER — завершить, BACKSPACE — стереть'
    ]
    for i, t in enumerate(tips):
        screen.blit(font.render(t, True, (235,235,240)), (10, 10 + i*20))

    if input_mode and input_target:
        caret_x = input_target.rect.x + 8 + font.size(input_target.name)[0] + 2
        screen.blit(font.render('▍', True, (255,220,120)), (caret_x, input_target.rect.y + 6))

    pygame.display.flip()

pygame.quit()
sys.exit()
