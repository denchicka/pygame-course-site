# -*- coding: utf-8 -*-
import pygame, sys, random

# Модуль 16 — Спрайты и группы (final)
# Покрыто: Sprite(image/rect), Group/GroupSingle/LayeredUpdates, update/draw, collide, kill, add/remove, z‑порядок.

pygame.init()
W, H = 900, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Модуль 16 — Спрайты (final)')
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 20)

BG = (24, 26, 32)

class Player(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image_normal = pygame.Surface((48, 48), pygame.SRCALPHA)
        self.image_normal.fill((90, 170, 250))
        pygame.draw.rect(self.image_normal, (240,240,255), self.image_normal.get_rect(), 2, border_radius=8)
        self.image_hit = pygame.Surface((48, 48), pygame.SRCALPHA)
        self.image_hit.fill((230, 90, 90))
        pygame.draw.rect(self.image_hit, (240,240,255), self.image_hit.get_rect(), 2, border_radius=8)
        self.image = self.image_normal
        self.rect = self.image.get_rect(center=pos)

        self.speed = 340.0
        self.hit_timer = 0.0

    def update(self, dt: float):
        keys = pygame.key.get_pressed()
        v = pygame.Vector2(
            (1 if keys[pygame.K_RIGHT] else 0) - (1 if keys[pygame.K_LEFT] else 0),
            (1 if keys[pygame.K_DOWN] else 0) - (1 if keys[pygame.K_UP] else 0)
        )
        if v.length_squared() > 0:
            v = v.normalize()
            self.rect.move_ip(v.x * self.speed * dt, v.y * self.speed * dt)
        self.rect.clamp_ip(screen.get_rect())

        self.image = self.image_hit if self.hit_timer > 0 else self.image_normal
        if self.hit_timer > 0: self.hit_timer -= dt

class Enemy(pygame.sprite.Sprite):
    def __init__(self, pos, vel):
        super().__init__()
        self.image = pygame.Surface((36, 36), pygame.SRCALPHA)
        self.image.fill((255, 190, 60))
        pygame.draw.rect(self.image, (40,40,40), self.image.get_rect(), 2, border_radius=8)
        self.rect = self.image.get_rect(center=pos)
        self.vel = pygame.Vector2(vel)

    def update(self, dt: float):
        self.rect.x += int(self.vel.x * dt)
        self.rect.y += int(self.vel.y * dt)
        if self.rect.left < 0 or self.rect.right > W:
            self.vel.x *= -1; self.rect.clamp_ip(screen.get_rect())
        if self.rect.top < 0 or self.rect.bottom > H:
            self.vel.y *= -1; self.rect.clamp_ip(screen.get_rect())

class Coin(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.base = pygame.Surface((22, 22), pygame.SRCALPHA)
        pygame.draw.circle(self.base, (120,220,140), (11,11), 11)
        pygame.draw.circle(self.base, (240,255,245), (11,11), 11, 2)
        self.image = self.base.copy()
        self.rect = self.image.get_rect(center=pos)
        self.t = 0.0

    def update(self, dt: float):
        # небольшое «дыхание» для анимации
        self.t += dt
        scale = 1.0 + 0.07 * (1 + pygame.math.sin(self.t * 4.0)) * 0.5
        size = max(12, min(28, int(22 * scale)))
        self.image = pygame.transform.smoothscale(self.base, (size, size))
        center = self.rect.center
        self.rect = self.image.get_rect(center=center)

# Слои рисования
layers = pygame.sprite.LayeredUpdates()

player = Player((W//2, H//2))
layers.add(player, layer=10)

enemies = pygame.sprite.Group()
coins = pygame.sprite.Group()

for _ in range(10):
    e = Enemy((random.randint(60, W-60), random.randint(60, H-60)),
              (random.choice([-220,-180,180,220]), random.choice([-220,-160,160,220])))
    enemies.add(e); layers.add(e, layer=5)

for _ in range(8):
    c = Coin((random.randint(40, W-40), random.randint(40, H-40)))
    coins.add(c); layers.add(c, layer=1)

score = 0

running = True
while running:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT: running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: running = False

    # Массовое обновление
    enemies.update(dt); coins.update(dt); player.update(dt)

    # Столкновения
    if pygame.sprite.spritecollide(player, enemies, dokill=False):
        player.hit_timer = 0.25

    got = pygame.sprite.spritecollide(player, coins, dokill=True)
    if got: score += len(got)

    # Пример groupcollide: враги съедают монеты (враг остаётся, монета пропадает)
    eaten = pygame.sprite.groupcollide(enemies, coins, False, True)
    # (ничего не делаем, просто демонстрация)

    # Рендер по слоям (автоматически по layer)
    screen.fill(BG)
    layers.draw(screen)

    ui = [
        'Стрелки — движение | ESC — выход',
        f'Группы: enemies={len(enemies)} coins={len(coins)} | Score={score}',
        'Слои: игрок (10), враги (5), монеты (1) — рисование сверху вниз'
    ]
    for i, msg in enumerate(ui):
        screen.blit(font.render(msg, True, (235,235,240)), (10, 10 + i*20))

    pygame.display.flip()

pygame.quit()
sys.exit()
